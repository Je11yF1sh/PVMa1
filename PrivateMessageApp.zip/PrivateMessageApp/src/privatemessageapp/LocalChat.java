/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package privatemessageapp;

import privatemessageapp.NewConvo;

/**
 *
 * @author Sam
 */
public class LocalChat extends NewConvo{

    public LocalChat(String convoName, int newMessages) {
        super(convoName, newMessages);
    }


    private int chatPin = 133420 ;
    

}
