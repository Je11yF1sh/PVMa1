
package privatemessageapp;

import controller.ConvoCntl;
import controller.NavigationCntl;
import javax.swing.JFrame;



public class PrivateMessageApp extends JFrame{

    /**
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NavigationCntl navCntl = new NavigationCntl();

    }
}
